import { certificationsData } from "../constants/certifications";

const Certifications = () => {
  return (
    <section className="py-4/5 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-4">
      <h2 className="text-1xl font-bold mb-6">Certifications</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {certificationsData.map((cert) => (
          <a 
            key={cert.id} 
            href={cert.link} 
            target="_blank" 
            rel="noopener noreferrer"
            /* Added the green glow and smooth transition below */
            className="block bg-card p-5 rounded-3xl border border-border transition-all duration-300 hover:border-green-500 hover:shadow-[0_0_20px_rgba(34,197,94,0.4)] hover:scale-[1.02] active:scale-[0.98]"
          >
            <div className="aspect-4/3 rounded-2xl overflow-hidden mb-5 border border-border">
              <img 
                src={cert.image} 
                alt={cert.title} 
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="text-l font-bold">{cert.title}</h3>
            <p className="text-muted-foreground text-sm">{cert.issuer}</p>
            <p className="text-emerald-400 uppercase text-xs font-semibold mt-2">
              View Verified Certificate
            </p>
          </a>
        ))}
      </div>
    </section>
  );
};

export default Certifications;