import type { Experience } from "../types";

export const experienceData: Experience[] = [
  {
    companyName: "JCG Marketing Group Inc.",
    jobTitle: "Junior Web Developer",
    date: "2025",
    current: true,
  },
  {
    companyName: "JAAA Motorparts Inc.",
    jobTitle: "Front-End Developer ",
    date: "2025",
    current: false,
  },
  {
    companyName: "McDonald's",
    jobTitle: "Service Crew",
    date: "2024",
    current: false,
  },
  {
    companyName: "Hello World!",
    jobTitle: "Wrote my first line of code",
    date: "2023",
    current: false,
  },
];
