export const certificationsData = [
  {
    id: 1,
    title: "CSS Mastery",
    issuer: "SoloLearn",
    image: "/CERT2.png", // Put images in public folder
    
  },
  {
    id: 2,
    title: "HTML Mastery",
    issuer: "SoloLearn",
    image: "/CERT1.png",
    
  },
   {
    id: 3,
    title: "JAVASCRIPT Mastery",
    issuer: "SoloLearn",
    image: "/CERT3.png", // Put images in public folder
    
  },
 





];