export const personalLinks = {
  resume: "https://drive.google.com/file/d/1McLlL5_8BElYr1sbPJ91zOv0jQj-1/view?usp=sharing", 
  email: "mailto:mikylaagan@gmail.com", 
};