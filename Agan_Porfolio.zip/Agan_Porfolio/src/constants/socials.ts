import { FaLinkedin, FaGithub, FaInstagram, FaFacebook } from "react-icons/fa";

export interface SocialLink {
  name: string;
  url: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const socialLinks: SocialLink[] = [
  {
    name: "LinkedIn",
    url: "https://www.linkedin.com/in/mikyla-agan-590806334/?skedirect=true",
    icon: FaLinkedin,
  },
  {
    name: "GitHub",
    url: "https://github.com/Mikylaagan",
    icon: FaGithub,
  },
  {
    name: "Instagram",
    url: "https://www.instagram.com/mikylagan/",
    icon: FaInstagram,
  },
  {
    name: "Facebook",
    url: "https://www.facebook.com/share/18FBWg3K/",
    icon: FaFacebook,
  }
];
