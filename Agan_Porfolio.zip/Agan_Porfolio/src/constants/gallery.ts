import type { GalleryItem } from "@/types";
import Image1 from "@/assets/images/gallery/me.jpeg";
import Image2 from "@/assets/images/gallery/me3.jpeg";
import Image3 from "@/assets/images/gallery/me4.jpeg";
import Image4 from "@/assets/images/gallery/me6.jpg";
import Image5 from "@/assets/images/gallery/cert.jpeg";
import Image6 from "@/assets/images/gallery/ok.jpeg";
import Image7 from "@/assets/images/gallery/code.jpeg";
import Image8 from "@/assets/images/gallery/Ok1.jpeg";
import Image9 from "@/assets/images/gallery/Ok2.jpeg";
import Image10 from "@/assets/images/gallery/ok8.jpg";
import Image11 from "@/assets/images/gallery/CERT8.png";
export const galleryData: GalleryItem[] = [
  {
    id: 1,
    imgSrc: Image1,
  },
  {
    id: 2,
    imgSrc: Image2,
  },
  {
    id: 3,
    imgSrc: Image3,
  },
  {
    id: 4,
    imgSrc: Image4,
  },
  {
    id: 5,
    imgSrc: Image5,
  },
  {
    id: 6,
    imgSrc: Image6,
  },
  {
    id: 7,
    imgSrc: Image7,
  },
  {
    id: 8,
    imgSrc: Image8,
  },
  {
    id: 9,
    imgSrc: Image9,
  },
  {
    id: 10,
    imgSrc: Image10,
  },
   {
    id: 11,
    imgSrc: Image11,
  },
 
];
